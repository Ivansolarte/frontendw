import { useState } from "react";
import { ProductHome } from "./components/products/product.home";

function App() {

  return (
    <div>
    <h1 className="text-3xl font-bold underline">
      Hello world!
    </h1>
    <ProductHome/>

    </div>
  );
}

export default App;
