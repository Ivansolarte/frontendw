import React from 'react'

export const TransactionHome = () => {
  return (
    <div>TransactionHome</div>
  )
}
