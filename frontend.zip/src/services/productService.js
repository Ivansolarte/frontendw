// src/services/productService.js

const BASE_URL = "http://localhost:3000"; // cambia si tu backend está en otra URL

export async function getProducts() {
  try {
    const response = await fetch(`${BASE_URL}/product`);
    if (!response.ok) {
      throw new Error("Error al obtener los productos");
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error en fetchProducts:", error);
    throw error;
  }
}
