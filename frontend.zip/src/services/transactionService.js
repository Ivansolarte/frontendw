// src/services/transactionService.js

const BASE_URL = 'http://localhost:3000';

export async function createTransaction(data) {
  const response = await fetch(`${BASE_URL}/transaction`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!response.ok) {
    throw new Error('Error al crear transacción');
  }
  return await response.json();
}

export async function simulatePayment(transactionId) {
  const response = await fetch(`${BASE_URL}/simulate-payment`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ transactionId }),
  });
  if (!response.ok) {
    throw new Error('Error al simular pago');
  }
  return await response.json();
}

